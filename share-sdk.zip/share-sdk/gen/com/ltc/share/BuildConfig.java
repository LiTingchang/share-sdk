/** Automatically generated file. DO NOT MODIFY */
package com.ltc.share;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}